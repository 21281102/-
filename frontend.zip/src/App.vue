<template>
  <div class="app">
    <!-- 左侧栏 -->
    <div class="sidebar">
      <div class="sidebar-header">
        <h2>💬 对话历史</h2>
        <button @click="createNewSession" class="new-session-btn" title="新建对话">
          ➕
        </button>
      </div>
      <div class="sessions-list">
        <div
          v-for="session in sessions"
          :key="session.id"
          :class="['session-item', { active: currentSessionId === session.id }]"
          @click="switchSession(session.id)"
        >
          <div class="session-info">
            <div class="session-title">{{ session.title }}</div>
            <div class="session-time">{{ formatTime(session.updatedAt) }}</div>
          </div>
          <button
            @click.stop="deleteSession(session.id)"
            class="delete-session-btn"
            title="删除对话"
          >
            🗑️
          </button>
        </div>
      </div>
    </div>
    
    <!-- 主聊天区域 -->
    <div class="chat-container">
      <div class="chat-header">
        <h1>🏥 医疗模型对话助手</h1>
        <p>基于医疗数据微调的智能对话系统</p>
        <div class="header-actions">
          <div class="model-selector">
            <label for="model-select">模型:</label>
            <select 
              id="model-select"
              v-model="currentModel" 
              @change="onModelChange"
              :disabled="loading"
              class="model-select"
            >
              <option value="local">本地模型</option>
              <option value="qwen_api">Qwen API</option>
            </select>
            <input
              v-if="currentModel === 'qwen_api'"
              v-model="qwenApiKey"
              @change="saveQwenApiKey"
              type="password"
              placeholder="输入 DashScope API Key"
              class="api-key-input"
              title="DashScope API Key"
            />
          </div>
          <button 
            @click="clearHistory" 
            :disabled="loading"
            class="clear-button"
            title="清空对话历史"
          >
            🗑️ 清空历史
          </button>
        </div>
      </div>
      
      <div class="messages-container" ref="messagesContainer">
        <div 
          v-for="(msg, idx) in messages" 
          :key="idx" 
          :class="['message', msg.role]"
        >
          <div class="message-avatar">
            {{ msg.role === 'user' ? '👤' : '🤖' }}
          </div>
          <div class="message-content">
            <div class="message-text">{{ msg.content }}</div>
          </div>
        </div>
        <div v-if="loading" class="message assistant">
          <div class="message-avatar">🤖</div>
          <div class="message-content">
            <div class="loading-dots">
              <span></span>
              <span></span>
              <span></span>
            </div>
          </div>
        </div>
      </div>

      <div class="input-container">
        <textarea
          v-model="input"
          @keypress="handleKeyPress"
          placeholder="输入您的问题..."
          rows="2"
          :disabled="loading"
        />
        <button 
          @click="handleSend" 
          :disabled="loading || !input.trim()"
          class="send-button"
        >
          {{ loading ? '发送中...' : '发送' }}
        </button>
      </div>
    </div>
  </div>
</template>

<script>
import axios from 'axios'

export default {
  name: 'App',
  data() {
    return {
      sessions: [], // 所有会话列表
      currentSessionId: null, // 当前会话ID
      messages: [
        {
          role: 'assistant',
          content: '您好！我是医疗助手，可以为您提供医疗相关的咨询和帮助。请问有什么可以帮您的吗？'
        }
      ],
      input: '',
      loading: false,
      currentModel: 'local',  // 当前选择的模型
      qwenApiKey: ''  // Qwen API Key
    }
  },
  mounted() {
    // 加载保存的模型选择
    const savedModel = localStorage.getItem('medical_chat_model')
    if (savedModel) {
      this.currentModel = savedModel
    }
    
    // 加载保存的 API Key
    const savedApiKey = localStorage.getItem('dashscope_api_key')
    if (savedApiKey) {
      this.qwenApiKey = savedApiKey
    }
    
    this.loadSessions()
    if (this.sessions.length === 0) {
      this.createNewSession()
    } else {
      // 如果有保存的当前会话ID，加载它；否则加载最近的一个会话
      if (this.currentSessionId) {
        const session = this.sessions.find(s => s.id === this.currentSessionId)
        if (session) {
          this.switchSession(this.currentSessionId)
        } else {
          this.switchSession(this.sessions[0].id)
        }
      } else {
        this.switchSession(this.sessions[0].id)
      }
    }
    this.$nextTick(() => {
      this.scrollToBottom()
    })
  },
  watch: {
    messages: {
      handler() {
        this.saveCurrentSession()
        this.$nextTick(() => {
          this.scrollToBottom()
        })
      },
      deep: true
    }
  },
  methods: {
    scrollToBottom() {
      const container = this.$refs.messagesContainer
      if (container) {
        container.scrollTop = container.scrollHeight
      }
    },
    async handleSend() {
      if (!this.input.trim() || this.loading) return

      const userMessage = { role: 'user', content: this.input.trim() }
      this.messages.push(userMessage)
      const currentInput = this.input.trim()
      this.input = ''
      this.loading = true

      try {
        console.log('发送聊天请求，使用模型:', this.currentModel)
        
        let cleanedResponse = ''
        
        if (this.currentModel === 'qwen_api') {
          // 使用 Qwen API（前端直接调用）
          if (!this.qwenApiKey) {
            throw new Error('请先设置 DashScope API Key')
          }
          
          cleanedResponse = await this.callQwenAPI(currentInput, this.messages)
        } else {
          // 使用本地模型（通过后端）
          const response = await axios.post('/api/chat', {
            message: currentInput,
            history: this.messages,
            model_type: 'local'
          })

          // 清理输出中的特殊标记
          cleanedResponse = response.data.response
            .replace(/<\|im_end\|>/g, '')
            .replace(/<\|im_start\|>/g, '')
            .replace(/<\|endoftext\|>/g, '')
            // 清理 `<think>` 标签及其内容
            .replace(/`<think>`.*?`<\/think>`/gis, '')
            .replace(/`<think>.*?<\/think>`/gis, '')
            .replace(/<think>.*?<\/think>/gis, '')
            .trim()
        }
        
        const assistantMessage = {
          role: 'assistant',
          content: cleanedResponse
        }
        this.messages.push(assistantMessage)
        // 更新会话标题（如果是第一条用户消息）
        this.updateSessionTitle()
      } catch (error) {
        console.error('Error:', error)
        let errorMsg = '抱歉，发生了错误。'
        
        if (error.code === 'ECONNREFUSED' || error.message.includes('ECONNRESET')) {
          errorMsg = '无法连接到后端服务，请确保后端服务正在运行（http://localhost:8000）'
        } else if (error.response) {
          const detail = error.response.data?.detail || error.response.data?.message || error.response.statusText
          errorMsg = `服务器错误 (${error.response.status}): ${detail}`
          
          // 如果是Qwen API相关的错误，提供更详细的提示
          if (this.currentModel === 'qwen_api') {
            if (error.response.status === 400) {
              // 400 错误通常是请求参数问题
              const errorData = error.response.data
              if (errorData && errorData.message) {
                errorMsg = `请求参数错误: ${errorData.message}`
              } else if (errorData && errorData.error) {
                errorMsg = `请求参数错误: ${errorData.error.message || JSON.stringify(errorData.error)}`
              } else {
                errorMsg = `请求参数错误 (400): ${detail}\n\n可能的原因：\n1. 模型名称不正确\n2. 请求格式不符合API要求\n3. 参数配置错误\n\n请查看浏览器控制台获取详细错误信息。`
              }
              console.error('Qwen API 400错误详情:', error.response.data)
            } else if (error.response.status === 401 || detail.includes('api_key') || detail.includes('unauthorized')) {
              errorMsg = 'API Key 无效或未设置。请在上方的输入框中输入正确的 DashScope API Key。'
            } else if (error.response.status === 429) {
              errorMsg = 'API 调用频率过高，请稍后再试。'
            } else if (error.response.status >= 500) {
              errorMsg = 'DashScope API 服务暂时不可用，请稍后再试。'
            }
          }
        } else if (error.request) {
          if (this.currentModel === 'qwen_api') {
            errorMsg = '无法连接到 DashScope API，请检查网络连接。'
          } else {
            errorMsg = '请求超时或网络错误，请检查后端服务是否正常运行'
          }
        } else if (error.message && error.message.includes('API Key')) {
          errorMsg = error.message
        }
        
        const errorMessage = {
          role: 'assistant',
          content: errorMsg
        }
        this.messages.push(errorMessage)
      } finally {
        this.loading = false
      }
    },
    handleKeyPress(e) {
      if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault()
        this.handleSend()
      }
    },
    // 会话管理方法
    createNewSession() {
      const newSession = {
        id: Date.now().toString(),
        title: this.generateSessionTitle(),
        messages: [
          {
            role: 'assistant',
            content: '您好！我是医疗助手，可以为您提供医疗相关的咨询和帮助。请问有什么可以帮您的吗？'
          }
        ],
        createdAt: Date.now(),
        updatedAt: Date.now()
      }
      this.sessions.unshift(newSession)
      this.currentSessionId = newSession.id
      this.messages = [...newSession.messages]
      this.saveSessions()
    },
    switchSession(sessionId) {
      const session = this.sessions.find(s => s.id === sessionId)
      if (session) {
        // 保存当前会话
        if (this.currentSessionId) {
          this.saveCurrentSession()
        }
        // 切换到新会话
        this.currentSessionId = sessionId
        // 如果会话有消息，使用会话的消息，否则使用默认欢迎消息
        if (session.messages && session.messages.length > 0) {
          this.messages = [...session.messages]
        } else {
          this.messages = [
            {
              role: 'assistant',
              content: '您好！我是医疗助手，可以为您提供医疗相关的咨询和帮助。请问有什么可以帮您的吗？'
            }
          ]
        }
        this.$nextTick(() => {
          this.scrollToBottom()
        })
      }
    },
    deleteSession(sessionId) {
      if (confirm('确定要删除这个对话吗？')) {
        const index = this.sessions.findIndex(s => s.id === sessionId)
        if (index !== -1) {
          this.sessions.splice(index, 1)
          this.saveSessions()
          
          // 如果删除的是当前会话
          if (this.currentSessionId === sessionId) {
            if (this.sessions.length > 0) {
              // 切换到第一个会话
              this.switchSession(this.sessions[0].id)
            } else {
              // 创建新会话
              this.createNewSession()
            }
          }
        }
      }
    },
    generateSessionTitle() {
      const now = new Date()
      const month = String(now.getMonth() + 1).padStart(2, '0')
      const day = String(now.getDate()).padStart(2, '0')
      const hour = String(now.getHours()).padStart(2, '0')
      const minute = String(now.getMinutes()).padStart(2, '0')
      return `${month}-${day} ${hour}:${minute}`
    },
    updateSessionTitle() {
      if (!this.currentSessionId) return
      const session = this.sessions.find(s => s.id === this.currentSessionId)
      if (session && this.messages.length > 1) {
        // 使用第一条用户消息作为标题（如果存在）
        const firstUserMessage = this.messages.find(msg => msg.role === 'user')
        if (firstUserMessage) {
          const title = firstUserMessage.content.substring(0, 20)
          session.title = title.length < firstUserMessage.content.length ? title + '...' : title
        }
      }
    },
    saveCurrentSession() {
      if (!this.currentSessionId) return
      const session = this.sessions.find(s => s.id === this.currentSessionId)
      if (session) {
        // 过滤掉欢迎消息
        const historyToSave = this.messages.filter(msg => 
          !(msg.role === 'assistant' && msg.content.includes('您好！我是医疗助手'))
        )
        session.messages = historyToSave.length > 0 ? [
          {
            role: 'assistant',
            content: '您好！我是医疗助手，可以为您提供医疗相关的咨询和帮助。请问有什么可以帮您的吗？'
          },
          ...historyToSave
        ] : this.messages
        session.updatedAt = Date.now()
        this.updateSessionTitle()
        this.saveSessions()
      }
    },
    saveSessions() {
      try {
        localStorage.setItem('medical_chat_sessions', JSON.stringify(this.sessions))
        localStorage.setItem('medical_chat_current_session', this.currentSessionId)
      } catch (error) {
        console.error('保存会话失败:', error)
      }
    },
    loadSessions() {
      try {
        const saved = localStorage.getItem('medical_chat_sessions')
        if (saved) {
          this.sessions = JSON.parse(saved)
          // 按更新时间排序
          this.sessions.sort((a, b) => b.updatedAt - a.updatedAt)
        }
        const currentId = localStorage.getItem('medical_chat_current_session')
        if (currentId && this.sessions.find(s => s.id === currentId)) {
          this.currentSessionId = currentId
        }
      } catch (error) {
        console.error('加载会话失败:', error)
        this.sessions = []
      }
    },
    onModelChange() {
      // 保存模型选择
      localStorage.setItem('medical_chat_model', this.currentModel)
      console.log('模型已切换为:', this.currentModel)
    },
    saveQwenApiKey() {
      // 保存 API Key
      localStorage.setItem('dashscope_api_key', this.qwenApiKey)
      console.log('API Key 已保存')
    },
    async callQwenAPI(userMessage, history) {
      // 构建消息列表
      const messages = []
      
      // 添加历史对话（只使用最近10轮，排除欢迎消息）
      if (history) {
        const filteredHistory = history.filter(msg => 
          !(msg.role === 'assistant' && msg.content.includes('您好！我是医疗助手'))
        )
        for (const msg of filteredHistory.slice(-10)) {
          const role = msg.role
          const content = msg.content
          if (role === 'user' || role === 'assistant') {
            messages.push({ role, content })
          }
        }
      }
      
      // 添加当前用户消息
      messages.push({ role: 'user', content: userMessage })
      
      try {
        // 调用 DashScope API
        // 注意：非流式调用时 enable_thinking 必须为 false
        const requestData = {
          model: 'qwen3-8b',
          messages: messages,
          temperature: 0.7,
          max_tokens: 512,
          stream: false,  // 明确设置为非流式调用
          enable_thinking: false  // 非流式调用时必须设置为 false
        }
        
        console.log('Qwen API 请求数据:', JSON.stringify(requestData, null, 2))
        console.log('请求 URL:', 'https://dashscope.aliyuncs.com/compatible-mode/v1/chat/completions')
        
        const response = await axios.post(
          'https://dashscope.aliyuncs.com/compatible-mode/v1/chat/completions',
          requestData,
          {
            headers: {
              'Authorization': `Bearer ${this.qwenApiKey}`,
              'Content-Type': 'application/json'
            }
          }
        )
        
        console.log('Qwen API 响应:', response.data)
        
        // 提取回复（qwen3-8b 可能返回思考内容和实际内容）
        const choice = response.data.choices[0]
        let reply = ''
        
        // 优先使用 content，如果没有则尝试其他字段
        if (choice.message && choice.message.content) {
          reply = choice.message.content
        } else if (choice.delta && choice.delta.content) {
          reply = choice.delta.content
        } else if (choice.message) {
          // 如果 message 是字符串
          reply = typeof choice.message === 'string' ? choice.message : ''
        }
        
        // 清理回复中的思考标记（如果有）
        reply = reply.replace(/<think>.*?<\/think>/gis, '')
        reply = reply.replace(/<think>.*?<\/think>/gis, '')
        reply = reply.replace(/<think>.*?<\/redacted_reasoning>/gis, '')
        
        return reply.trim()
      } catch (error) {
        // 添加详细的错误日志
        console.error('Qwen API 调用错误:', {
          status: error.response?.status,
          statusText: error.response?.statusText,
          data: error.response?.data,
          message: error.message,
          requestData: error.config?.data ? JSON.parse(error.config.data) : null
        })
        
        // 如果是 400 错误，检查是否是 enable_thinking 相关
        if (error.response?.status === 400 && error.response?.data) {
          const errorData = error.response.data
          console.error('400 错误完整详情:', JSON.stringify(errorData, null, 2))
          
          // 检查错误信息中是否提到 enable_thinking
          const errorMsg = JSON.stringify(errorData).toLowerCase()
          if (errorMsg.includes('enable_thinking')) {
            console.warn('⚠️ 检测到 enable_thinking 相关错误')
            console.warn('请检查：')
            console.warn('1. 浏览器缓存是否已清除（Ctrl+Shift+R 硬刷新）')
            console.warn('2. 前端服务是否已重启')
            console.warn('3. 实际发送的请求数据:', error.config?.data)
          }
        }
        
        throw error
      }
    },
    clearHistory() {
      if (confirm('确定要清空当前对话历史吗？')) {
        this.messages = [
          {
            role: 'assistant',
            content: '您好！我是医疗助手，可以为您提供医疗相关的咨询和帮助。请问有什么可以帮您的吗？'
          }
        ]
        this.saveCurrentSession()
      }
    },
    formatTime(timestamp) {
      const date = new Date(timestamp)
      const now = new Date()
      const diff = now - date
      
      if (diff < 60000) { // 1分钟内
        return '刚刚'
      } else if (diff < 3600000) { // 1小时内
        return `${Math.floor(diff / 60000)}分钟前`
      } else if (diff < 86400000) { // 24小时内
        return `${Math.floor(diff / 3600000)}小时前`
      } else if (diff < 604800000) { // 7天内
        return `${Math.floor(diff / 86400000)}天前`
      } else {
        const month = String(date.getMonth() + 1).padStart(2, '0')
        const day = String(date.getDate()).padStart(2, '0')
        return `${month}-${day}`
      }
    }
  }
}
</script>

<style scoped>
.app {
  width: 100%;
  height: 100vh;
  display: flex;
  flex-direction: row;
  background: #f0f2f5;
}

/* 左侧栏样式 */
.sidebar {
  width: 280px;
  background: white;
  border-right: 1px solid #e9ecef;
  display: flex;
  flex-direction: column;
  height: 100vh;
  overflow: hidden;
}

.sidebar-header {
  padding: 20px;
  border-bottom: 1px solid #e9ecef;
  display: flex;
  justify-content: space-between;
  align-items: center;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  color: white;
}

.sidebar-header h2 {
  margin: 0;
  font-size: 18px;
  font-weight: 600;
}

.new-session-btn {
  background: rgba(255, 255, 255, 0.2);
  border: none;
  color: white;
  width: 32px;
  height: 32px;
  border-radius: 8px;
  cursor: pointer;
  font-size: 18px;
  display: flex;
  align-items: center;
  justify-content: center;
  transition: all 0.2s;
}

.new-session-btn:hover {
  background: rgba(255, 255, 255, 0.3);
  transform: scale(1.1);
}

.sessions-list {
  flex: 1;
  overflow-y: auto;
  padding: 10px;
}

.session-item {
  padding: 12px;
  margin-bottom: 8px;
  border-radius: 8px;
  cursor: pointer;
  transition: all 0.2s;
  display: flex;
  justify-content: space-between;
  align-items: center;
  background: #f8f9fa;
  border: 2px solid transparent;
}

.session-item:hover {
  background: #e9ecef;
  transform: translateX(4px);
}

.session-item.active {
  background: linear-gradient(135deg, #667eea15 0%, #764ba215 100%);
  border-color: #667eea;
}

.session-info {
  flex: 1;
  min-width: 0;
}

.session-title {
  font-size: 14px;
  font-weight: 500;
  color: #333;
  margin-bottom: 4px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.session-item.active .session-title {
  color: #667eea;
  font-weight: 600;
}

.session-time {
  font-size: 12px;
  color: #888;
}

.delete-session-btn {
  background: none;
  border: none;
  font-size: 14px;
  cursor: pointer;
  padding: 4px 8px;
  opacity: 0.5;
  transition: all 0.2s;
  border-radius: 4px;
}

.delete-session-btn:hover {
  opacity: 1;
  background: rgba(255, 0, 0, 0.1);
}

.chat-container {
  flex: 1;
  background: white;
  display: flex;
  flex-direction: column;
  height: 100vh;
  overflow: hidden;
  margin: 0;
  border-radius: 0;
  box-shadow: none;
}

.chat-header {
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  color: white;
  padding: 25px;
  text-align: center;
}

.chat-header h1 {
  font-size: 24px;
  margin-bottom: 8px;
  font-weight: 600;
}

.chat-header p {
  font-size: 14px;
  opacity: 0.9;
}

.header-actions {
  display: flex;
  gap: 10px;
  justify-content: center;
  align-items: center;
  margin-top: 15px;
}

.model-selector {
  display: flex;
  align-items: center;
  gap: 8px;
}

.model-selector label {
  font-size: 13px;
  opacity: 0.9;
}

.model-select {
  padding: 6px 12px;
  border: none;
  border-radius: 8px;
  font-size: 13px;
  font-weight: 500;
  background: rgba(255, 255, 255, 0.2);
  color: white;
  backdrop-filter: blur(10px);
  cursor: pointer;
  transition: all 0.2s;
}

.model-select:hover:not(:disabled) {
  background: rgba(255, 255, 255, 0.3);
}

.model-select:disabled {
  opacity: 0.5;
  cursor: not-allowed;
}

.model-select option {
  background: #667eea;
  color: white;
}

.api-key-input {
  padding: 6px 12px;
  border: none;
  border-radius: 8px;
  font-size: 12px;
  background: rgba(255, 255, 255, 0.2);
  color: white;
  backdrop-filter: blur(10px);
  width: 200px;
  transition: all 0.2s;
}

.api-key-input::placeholder {
  color: rgba(255, 255, 255, 0.7);
}

.api-key-input:focus {
  outline: none;
  background: rgba(255, 255, 255, 0.3);
  width: 250px;
}

.api-key-input::-webkit-input-placeholder {
  color: rgba(255, 255, 255, 0.7);
}

.api-key-input {
  padding: 6px 12px;
  border: none;
  border-radius: 8px;
  font-size: 12px;
  background: rgba(255, 255, 255, 0.2);
  color: white;
  backdrop-filter: blur(10px);
  width: 200px;
  transition: all 0.2s;
}

.api-key-input::placeholder {
  color: rgba(255, 255, 255, 0.7);
}

.api-key-input:focus {
  outline: none;
  background: rgba(255, 255, 255, 0.3);
  width: 250px;
}

.api-key-input::-webkit-input-placeholder {
  color: rgba(255, 255, 255, 0.7);
}

.clear-button {
  padding: 8px 16px;
  border: none;
  border-radius: 8px;
  font-size: 13px;
  font-weight: 500;
  cursor: pointer;
  transition: all 0.2s;
  background: rgba(255, 255, 255, 0.2);
  color: white;
  backdrop-filter: blur(10px);
}

.clear-button:hover:not(:disabled) {
  background: rgba(255, 255, 255, 0.3);
  transform: translateY(-2px);
}

.clear-button:disabled {
  opacity: 0.5;
  cursor: not-allowed;
}

.messages-container {
  flex: 1;
  overflow-y: auto;
  padding: 20px;
  background: #f8f9fa;
}

.message {
  display: flex;
  margin-bottom: 20px;
  animation: fadeIn 0.3s ease-in;
}

@keyframes fadeIn {
  from {
    opacity: 0;
    transform: translateY(10px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

.message.user {
  flex-direction: row-reverse;
}

.message-avatar {
  width: 40px;
  height: 40px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 20px;
  flex-shrink: 0;
  background: white;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
}

.message-content {
  max-width: 70%;
  margin: 0 12px;
}

.message.user .message-content {
  text-align: right;
}

.message-text {
  background: white;
  padding: 12px 16px;
  border-radius: 12px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
  line-height: 1.6;
  word-wrap: break-word;
  white-space: pre-wrap;
}

.message.user .message-text {
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  color: white;
}

.loading-dots {
  display: flex;
  gap: 6px;
  padding: 12px 16px;
}

.loading-dots span {
  width: 8px;
  height: 8px;
  border-radius: 50%;
  background: #667eea;
  animation: bounce 1.4s infinite ease-in-out both;
}

.loading-dots span:nth-child(1) {
  animation-delay: -0.32s;
}

.loading-dots span:nth-child(2) {
  animation-delay: -0.16s;
}

@keyframes bounce {
  0%, 80%, 100% {
    transform: scale(0);
  }
  40% {
    transform: scale(1);
  }
}

.input-container {
  padding: 20px;
  background: white;
  border-top: 1px solid #e9ecef;
  display: flex;
  gap: 12px;
  align-items: flex-end;
}

.input-container textarea {
  flex: 1;
  padding: 12px 16px;
  border: 2px solid #e9ecef;
  border-radius: 12px;
  font-size: 14px;
  font-family: inherit;
  resize: none;
  outline: none;
  transition: border-color 0.3s;
}

.input-container textarea:focus {
  border-color: #667eea;
}

.input-container textarea:disabled {
  background: #f8f9fa;
  cursor: not-allowed;
}

.send-button {
  padding: 12px 24px;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  color: white;
  border: none;
  border-radius: 12px;
  font-size: 14px;
  font-weight: 600;
  cursor: pointer;
  transition: transform 0.2s, box-shadow 0.2s;
  white-space: nowrap;
}

.send-button:hover:not(:disabled) {
  transform: translateY(-2px);
  box-shadow: 0 4px 12px rgba(102, 126, 234, 0.4);
}

.send-button:active:not(:disabled) {
  transform: translateY(0);
}

.send-button:disabled {
  opacity: 0.6;
  cursor: not-allowed;
}

/* 滚动条样式 */
.messages-container::-webkit-scrollbar {
  width: 6px;
}

.messages-container::-webkit-scrollbar-track {
  background: #f1f1f1;
}

.messages-container::-webkit-scrollbar-thumb {
  background: #888;
  border-radius: 3px;
}

.messages-container::-webkit-scrollbar-thumb:hover {
  background: #555;
}

</style>


